PYTHON ACADEMY - ANDROID APP PROJECT
===================================

This project wraps your uploaded Python Academy website in an Android app.
Your website files are bundled inside the app, so the main pages can open
without hosting the site. Features that need the internet (for example Google
Fonts or any online APIs) still need an internet connection.

HOW TO BUILD THE APK
1. Install Android Studio on a computer:
   https://developer.android.com/studio
2. Extract this ZIP file.
3. Open Android Studio -> Open -> select the extracted PythonAcademy folder.
4. Allow Android Studio to sync/download the Android Gradle plugin and SDK.
5. Select Build -> Build Bundle(s) / APK(s) -> Build APK(s).
6. When the build finishes, click "locate" in the notification.
   The APK is normally at:
   app/build/outputs/apk/debug/app-debug.apk
7. Send that APK file to the people you want to share it with.

APP DETAILS
- App name: Python Academy
- Package: com.sifaan.pythonacademy
- Minimum Android: Android 6.0 (API 23)
- Version: 1.0

IMPORTANT
- This is an Android Studio source project, not a compiled APK yet.
- This environment does not have the Android SDK/Gradle build tools installed,
  so it cannot compile and sign the APK here.
- The debug APK is suitable for testing and direct sharing with people you trust.
  For a public release, create a signed release APK in Android Studio.
- Never share API keys or secret credentials inside website code.
